import { Component, OnInit } from '@angular/core';
declare var $:any;
declare const M;

declare var fullWidth;

@Component({
  selector: 'app-android',
  templateUrl: './android.component.html',
  styleUrls: ['./android.component.css']
})
export class AndroidComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    this.jquery_code();
    this.faq_code();
  }

  jquery_code(){

    document.addEventListener('DOMContentLoaded', function() {
      var elems = document.querySelectorAll('.sidenav');
      var instances = M.Sidenav.init(elems, Option);
    });

    $(document).ready(function(){
      $('.sidenav').sidenav();
    });

    document.addEventListener('DOMContentLoaded', function() {
      var elems = document.querySelectorAll('.carousel');
      var instances = M.Carousel.init(elems, Option);
      
    });
  
    // Or with jQuery
  
    $(document).ready(function(){
      $('.carousel').carousel();

    });

      //image pop up
    document.addEventListener('DOMContentLoaded', function() {
      var elems = document.querySelectorAll('.materialboxed');
      var instances = M.Materialbox.init(elems, Option);
    });
  
    // Or with jQuery
  
    $(document).ready(function(){
      $('.materialboxed').materialbox();
    });
          
    $('#textarea1').val('New Text');
    M.textareaAutoResize($('#textarea1'));
  

        
  
  }

  faq_code(){

    const items = document.querySelectorAll(".accordion a");

function toggleAccordion(){
  this.classList.toggle('active');
  this.nextElementSibling.classList.toggle('active');
}

items.forEach(item => item.addEventListener('click', toggleAccordion));
  }

}
