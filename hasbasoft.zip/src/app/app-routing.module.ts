import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AndroidComponent } from './android/android.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { WebsiteComponent } from './website/website.component';


const routes: Routes = [
  { path: 'home', component: HomepageComponent},
  {  path: '', component:HomepageComponent},
  {  path: 'android', component:AndroidComponent},
  {  path: 'login', component:LoginComponent},
  {  path: 'website', component:WebsiteComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
