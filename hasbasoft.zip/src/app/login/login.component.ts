import { Component, OnInit } from '@angular/core';
import {AuthService, SocialUser,FacebookLoginProvider,GoogleLoginProvider,LinkedinLoginProvider} from 'ng4-social-login'
import { Router } from '@angular/router';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public user: any = SocialUser;
  message = 'success';

  constructor(


    private socialAuthService: AuthService,
            private router: Router



  ) {}

  facebooklogin(){
   
    this.socialAuthService.signIn(FacebookLoginProvider.PROVIDER_ID).then((userData) =>{

      this.user = userData;
      // console.log(this.message)
        // this.router.navigate(['/']);
    
    
    });
  }

  googlelogin(){
      
    this.socialAuthService.signIn(GoogleLoginProvider.PROVIDER_ID).then((userData) =>{

      this.user = userData;
      
      console.log(this.message)
      this.router.navigate(['/android']);
      
    });
  
}

  linkedinlogin(){
    this.socialAuthService.signIn(GoogleLoginProvider.PROVIDER_ID).then((userData) =>{

      this.user = userData;


    });
  }

  ngOnInit() {
    this.jquery_code();
  }


  jquery_code() {

    const signUpButton = document.getElementById('signUp');
    const signInButton = document.getElementById('signIn');
    const container = document.getElementById('container');

    signUpButton.addEventListener('click', () => {
      container.classList.add("right-panel-active");
    });

    signInButton.addEventListener('click', () => {
      container.classList.remove("right-panel-active");
    });

    

  }

}

