import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AndroidComponent } from './android/android.component';
import { LoginComponent } from './login/login.component';

import {SocialLoginModule,AuthServiceConfig,FacebookLoginProvider,GoogleLoginProvider,LinkedinLoginProvider} from 'ng4-social-login';
import { WebsiteComponent } from './website/website.component';

const config = new AuthServiceConfig([
{

  id: FacebookLoginProvider.PROVIDER_ID,
  provider: new FacebookLoginProvider('561451471366399')

},
{

  id: GoogleLoginProvider.PROVIDER_ID,
  provider: new GoogleLoginProvider('764569500467-630lhlmfiu82kdtgh2gnih3n2t8913b9.apps.googleusercontent.com')

},
{

  id: LinkedinLoginProvider.PROVIDER_ID,
  provider: new LinkedinLoginProvider('81cqskeklemmjt')

},


], false);

export function provideConfig(){

  return config;
}

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    AndroidComponent,
    LoginComponent,
    WebsiteComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SocialLoginModule
  ],
  providers: [

    {provide:AuthServiceConfig,useFactory: provideConfig}


  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
